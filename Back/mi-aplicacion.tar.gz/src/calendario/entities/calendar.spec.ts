import { Calendar } from './calendar';

describe('Calendar', () => {
  it('should be defined', () => {
    expect(new Calendar()).toBeDefined();
  });
});
