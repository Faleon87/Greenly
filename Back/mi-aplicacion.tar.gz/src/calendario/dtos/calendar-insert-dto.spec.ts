import { CalendarInsertDto } from './calendar-insert-dto';

describe('CalendarInsertDto', () => {
  it('should be defined', () => {
    expect(new CalendarInsertDto()).toBeDefined();
  });
});
