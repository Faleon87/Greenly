import { Plagas } from './plagas';

describe('Plagas', () => {
  it('should be defined', () => {
    expect(new Plagas()).toBeDefined();
  });
});
