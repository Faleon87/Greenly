import { PlagasDtoDetail } from './plagas-dto-detail';

describe('PlagasDtoDetail', () => {
  it('should be defined', () => {
    expect(new PlagasDtoDetail()).toBeDefined();
  });
});
