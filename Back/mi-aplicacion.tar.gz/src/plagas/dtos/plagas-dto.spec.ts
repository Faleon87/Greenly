import { PlagasDto } from './plagas-dto';

describe('PlagasDto', () => {
  it('should be defined', () => {
    expect(new PlagasDto()).toBeDefined();
  });
});
