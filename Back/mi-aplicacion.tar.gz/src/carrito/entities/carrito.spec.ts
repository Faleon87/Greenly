import { Carrito } from './carrito';

describe('Carrito', () => {
  it('should be defined', () => {
    expect(new Carrito()).toBeDefined();
  });
});
