"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFertilizanteDto = void 0;
var CreateFertilizanteDto = /** @class */ (function () {
    function CreateFertilizanteDto() {
    }
    return CreateFertilizanteDto;
}());
exports.CreateFertilizanteDto = CreateFertilizanteDto;
