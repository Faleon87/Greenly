export class CreateFertilizanteDto {

    readonly idFertilizante: number;

    readonly nombreFertilizante: string;
    
    readonly img: string;

}
