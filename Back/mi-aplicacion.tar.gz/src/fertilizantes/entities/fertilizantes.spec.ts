import { Fertilizantes } from './fertilizantes';

describe('Fertilizantes', () => {
  it('should be defined', () => {
    expect(new Fertilizantes()).toBeDefined();
  });
});
