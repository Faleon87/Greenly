import { Tarjeta } from './tarjeta';

describe('Tarjeta', () => {
  it('should be defined', () => {
    expect(new Tarjeta()).toBeDefined();
  });
});
