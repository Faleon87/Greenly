import { Controller } from '@nestjs/common';

@Controller('abonos')
export class AbonosController {}
