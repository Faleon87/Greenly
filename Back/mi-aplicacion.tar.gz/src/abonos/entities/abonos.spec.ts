import { Abonos } from './abonos';

describe('Abonos', () => {
  it('should be defined', () => {
    expect(new Abonos()).toBeDefined();
  });
});
