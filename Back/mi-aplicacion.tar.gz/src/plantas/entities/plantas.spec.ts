import { Plantas } from './plantas';

describe('Plantas', () => {
  it('should be defined', () => {
    expect(new Plantas()).toBeDefined();
  });
});
