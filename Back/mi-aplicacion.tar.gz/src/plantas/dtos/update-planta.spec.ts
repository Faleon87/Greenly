import { UpdatePlantasDto } from './update-planta-dto';

describe('PlantaDto', () => {
  it('should be defined', () => {
    expect(new UpdatePlantasDto()).toBeDefined();
  });
});
