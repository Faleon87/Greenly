import { GetPlantas } from './get-plantas';

describe('GetPlantas', () => {
  it('should be defined', () => {
    expect(new GetPlantas()).toBeDefined();
  });
});
