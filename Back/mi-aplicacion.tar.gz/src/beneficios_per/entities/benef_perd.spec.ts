import { BenefPerd } from './benef_perd';

describe('BenefPerd', () => {
  it('should be defined', () => {
    expect(new BenefPerd()).toBeDefined();
  });
});
