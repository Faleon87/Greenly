import { Controller } from '@nestjs/common';

@Controller('herramientas')
export class HerramientasController {}
