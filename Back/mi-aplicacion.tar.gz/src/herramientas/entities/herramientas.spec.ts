import { Herramientas } from './herramientas';

describe('Herramientas', () => {
  it('should be defined', () => {
    expect(new Herramientas()).toBeDefined();
  });
});
