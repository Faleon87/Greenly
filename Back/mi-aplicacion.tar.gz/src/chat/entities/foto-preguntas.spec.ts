import { FotoPreguntas } from './foto-preguntas';

describe('FotoPreguntas', () => {
  it('should be defined', () => {
    expect(new FotoPreguntas()).toBeDefined();
  });
});
