import { Reports } from '../entities/reports';

describe('Reports', () => {
  it('should be defined', () => {
    expect(new Reports()).toBeDefined();
  });
});
