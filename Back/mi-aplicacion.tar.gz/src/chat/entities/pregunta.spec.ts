import { Pregunta } from './pregunta';

describe('Pregunta', () => {
  it('should be defined', () => {
    expect(new Pregunta()).toBeDefined();
  });
});
