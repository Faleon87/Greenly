import { Respuestas } from './respuestas';

describe('Respuestas', () => {
  it('should be defined', () => {
    expect(new Respuestas()).toBeDefined();
  });
});
