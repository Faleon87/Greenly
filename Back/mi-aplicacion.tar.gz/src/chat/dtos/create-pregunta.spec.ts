import { CreatePregunta } from './create-pregunta';

describe('CreatePregunta', () => {
  it('should be defined', () => {
    expect(new CreatePregunta()).toBeDefined();
  });
});
