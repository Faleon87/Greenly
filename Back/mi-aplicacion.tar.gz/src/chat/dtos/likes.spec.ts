import { Likes } from './likes';

describe('Likes', () => {
  it('should be defined', () => {
    expect(new Likes()).toBeDefined();
  });
});
