import { FotoPregunta } from './foto-pregunta';

describe('FotoPregunta', () => {
  it('should be defined', () => {
    expect(new FotoPregunta()).toBeDefined();
  });
});
