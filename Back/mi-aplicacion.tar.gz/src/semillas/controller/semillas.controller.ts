import { Controller } from '@nestjs/common';

@Controller('semillas')
export class SemillasController {}
