import { Semillas } from './semillas';

describe('Semillas', () => {
  it('should be defined', () => {
    expect(new Semillas()).toBeDefined();
  });
});
