import { DtoproductoDtoget } from './dtoproducto-dtoget';

describe('DtoproductoDtoget', () => {
  it('should be defined', () => {
    expect(new DtoproductoDtoget()).toBeDefined();
  });
});
