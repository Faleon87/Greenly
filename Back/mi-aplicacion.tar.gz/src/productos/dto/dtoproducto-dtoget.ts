export class DtoproductoDtoget {

  readonly  idProducto: number;
  readonly  nombre: string;
  readonly  precio: number;
  readonly  stock: number;
  readonly  imagen: string;
  readonly  Categoria: string;

}
