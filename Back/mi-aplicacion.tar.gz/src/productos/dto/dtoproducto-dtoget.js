"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DtoproductoDtoget = void 0;
var DtoproductoDtoget = /** @class */ (function () {
    function DtoproductoDtoget() {
    }
    return DtoproductoDtoget;
}());
exports.DtoproductoDtoget = DtoproductoDtoget;
