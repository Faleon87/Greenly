import { Productos } from './productos';

describe('Productos', () => {
  it('should be defined', () => {
    expect(new Productos()).toBeDefined();
  });
});
